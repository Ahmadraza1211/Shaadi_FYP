/**
 * ShaadiSahulat - Product Model
 * ================================
 * MongoDB schema for wedding dress products in the catalog.
 * Each product belongs to one of 8 categories.
 */

const mongoose = require("mongoose");

const productSchema = new mongoose.Schema(
  {
    product_id: {
      type: String,
      required: true,
      unique: true,
      trim: true,
      // Format: BRD-001, GRM-001, etc.
    },
    name: {
      type: String,
      required: true,
      trim: true,
    },
    category: {
      type: String,
      required: true,
      enum: [
        "bridal_lehenga",
        "bridal_sharara",
        "bridal_gown",
        "bridal_saree",
        "bridal_maxi",
        "groom_sherwani",
        "groom_kurta",
        "groom_waistcoat",
      ],
    },
    price_pkr: {
      type: Number,
      required: true,
      min: 0,
    },
    description: {
      type: String,
      default: "",
    },
    image_url: {
      type: String,
      default: "",
    },
    thumbnail_url: {
      type: String,
      default: "",
    },
    seller_id: {
      type: String,
      default: "",
    },
    is_available: {
      type: Boolean,
      default: true,
    },
    tags: [{
      type: String,
    }],
    // Optional: embedding vector stored directly in DB
    embedding_128: {
      type: [Number],
      default: [],
    },
  },
  {
    timestamps: true,
  }
);

// Index for fast category lookups
productSchema.index({ category: 1 });
productSchema.index({ product_id: 1 });
productSchema.index({ price_pkr: 1 });

module.exports = mongoose.model("Product", productSchema);
