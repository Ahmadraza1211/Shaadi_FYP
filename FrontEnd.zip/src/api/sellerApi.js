/**
 * ShaadiSahulat - Seller API Client
 * ===================================
 * All calls go through the Node.js backend at port 5000.
 * Images uploaded to the ML Flask service are served from port 5002.
 */

const BASE_URL   = "http://localhost:5000/api/seller";
export const ML_URL = "http://localhost:5002";

// ── Seller registration / auth ────────────────────────────────────────────

export async function registerSeller({ name, email, password, phone, city }) {
  const res = await fetch(`${BASE_URL}/register`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ name, email, password, phone, city }),
  });
  return res.json();
}

export async function loginSeller({ email, password }) {
  const res = await fetch(`${BASE_URL}/login`, {
    method:  "POST",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify({ email, password }),
  });
  return res.json();
}

export async function getSellerByEmail(email) {
  const res = await fetch(`${BASE_URL}/by-email?email=${encodeURIComponent(email)}`);
  return res.json();
}

export async function getSellerProfile(sellerId) {
  const res = await fetch(`${BASE_URL}/profile/${sellerId}`);
  return res.json();
}

// ── Product management ────────────────────────────────────────────────────

/**
 * Upload a new product with up to 5 images.
 *
 * @param {Object} fields  — { seller_id, title, description, category, color,
 *                             fabric, embroidery_type, bridal_type, price,
 *                             discount_price, stock_quantity }
 * @param {File[]} images  — File objects from <input type="file" multiple>
 */
export async function uploadProduct(fields, images) {
  const form = new FormData();
  for (const [key, val] of Object.entries(fields)) {
    if (val !== undefined && val !== "") form.append(key, String(val));
  }
  for (const img of images) {
    form.append("images", img);
  }
  const res = await fetch(`${BASE_URL}/product`, { method: "POST", body: form });
  return res.json();
}

export async function listProducts({ sellerId, category, status, page = 1, limit = 20 } = {}) {
  const params = new URLSearchParams();
  if (sellerId) params.set("seller_id", sellerId);
  if (category) params.set("category", category);
  if (status)   params.set("status",   status);
  params.set("page",  page);
  params.set("limit", limit);
  const res = await fetch(`${BASE_URL}/products?${params}`);
  return res.json();
}

export async function getProduct(productId) {
  const res = await fetch(`${BASE_URL}/product/${productId}`);
  return res.json();
}

export async function updateProduct(productId, updates) {
  const res = await fetch(`${BASE_URL}/product/${productId}`, {
    method:  "PUT",
    headers: { "Content-Type": "application/json" },
    body:    JSON.stringify(updates),
  });
  return res.json();
}

export async function deleteProduct(productId) {
  const res = await fetch(`${BASE_URL}/product/${productId}`, { method: "DELETE" });
  return res.json();
}

// ── Image URL helper ──────────────────────────────────────────────────────

/**
 * Convert a relative image URL from the API ("/images/...") to a full URL
 * served by the Flask ML service.
 */
export function resolveImageUrl(imageUrl) {
  if (!imageUrl) return "";
  if (imageUrl.startsWith("http")) return imageUrl;
  return `${ML_URL}${imageUrl}`;
}

export default {
  registerSeller,
  loginSeller,
  getSellerByEmail,
  getSellerProfile,
  uploadProduct,
  listProducts,
  getProduct,
  updateProduct,
  deleteProduct,
  resolveImageUrl,
};
