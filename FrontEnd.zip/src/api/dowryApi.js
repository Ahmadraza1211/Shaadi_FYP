import axios from 'axios';

const API_BASE = import.meta.env.VITE_API_URL || '/api';

const dowryApi = {
  estimate: async (data) => {
    const response = await axios.post(`${API_BASE}/dowry/estimate`, data);
    return response.data;
  },

  save: async (data) => {
    const response = await axios.post(`${API_BASE}/dowry/save`, data);
    return response.data;
  },

  getHistory: async (userId) => {
    const response = await axios.get(`${API_BASE}/dowry/history/${userId}`);
    return response.data;
  },

  ruleOnlyEstimate: async (data) => {
    const response = await axios.post(`${API_BASE}/dowry/rule-only`, data);
    return response.data;
  },

  initML: async (numRecords = 150) => {
    const response = await axios.post(`${API_BASE}/dowry/ml/init`, { num_records: numRecords });
    return response.data;
  },

  getMLStats: async () => {
    const response = await axios.get(`${API_BASE}/dowry/ml/stats`);
    return response.data;
  },
};

export default dowryApi;
