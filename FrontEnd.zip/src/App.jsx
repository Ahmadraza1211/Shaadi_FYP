import React, { useState } from 'react';
import VisualRecPage from './components/VisualRec/VisualRecPage';
import SellerPage from './components/Seller/SellerPage';

const VIEWS = [
  { id: 'buyer',  label: 'Find Dresses',  desc: 'Upload a photo and discover similar styles' },
  { id: 'seller', label: 'Seller Panel',  desc: 'Register & manage your bridal listings' },
];

function App() {
  const [userId] = useState(() => 'user-' + Math.random().toString(36).substr(2, 9));
  const [view, setView] = useState('buyer');

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-purple-100 sticky top-0 z-50">
        <div className="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-600 to-pink-500 rounded-xl flex items-center justify-center text-white font-bold text-lg">
              S
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-800">ShaadiSahulat</h1>
              <p className="text-xs text-gray-500">Wedding Planning Platform</p>
            </div>
          </div>

          {/* View switcher */}
          <div className="flex gap-1 bg-gray-100 p-1 rounded-xl">
            {VIEWS.map((v) => (
              <button
                key={v.id}
                onClick={() => setView(v.id)}
                className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                  view === v.id
                    ? 'bg-white text-purple-700 shadow-sm'
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                {v.label}
              </button>
            ))}
          </div>

          <span className="text-sm text-gray-400 hidden sm:block">ID: {userId.slice(0, 12)}</span>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-6">
        {view === 'buyer'
          ? <VisualRecPage userId={userId} />
          : <SellerPage />
        }
      </main>

      {/* Footer */}
      <footer className="text-center py-4 text-sm text-gray-400 border-t border-gray-100">
        ShaadiSahulat — FYP 2026 | NUCES Chiniot-Faisalabad
      </footer>
    </div>
  );
}

export default App;
