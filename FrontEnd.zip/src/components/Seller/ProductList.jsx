import React, { useState, useEffect, useCallback } from 'react';
import sellerApi from '../../api/sellerApi';

const STATUS_COLORS = {
  available:   'bg-green-100 text-green-700',
  processing:  'bg-yellow-100 text-yellow-700',
  out_of_stock:'bg-red-100 text-red-700',
  hidden:      'bg-gray-100 text-gray-600',
};

const STATUS_OPTIONS = ['available', 'out_of_stock', 'hidden', 'processing'];

export default function ProductList({ sellerId, refreshTrigger }) {
  const [products, setProducts]   = useState([]);
  const [total, setTotal]         = useState(0);
  const [page, setPage]           = useState(1);
  const [loading, setLoading]     = useState(false);
  const [deleting, setDeleting]   = useState(null);
  const [editId, setEditId]       = useState(null);
  const [editStatus, setEditStatus] = useState('');
  const [error, setError]         = useState('');

  const load = useCallback(async () => {
    if (!sellerId) return;
    setLoading(true);
    setError('');
    try {
      const data = await sellerApi.listProducts({ sellerId, page, limit: 10 });
      if (data.success !== false) {
        setProducts(data.products || []);
        setTotal(data.total || 0);
      } else {
        setError(data.error || 'Failed to load products.');
      }
    } catch (err) {
      setError('Network error: ' + err.message);
    } finally {
      setLoading(false);
    }
  }, [sellerId, page]);

  useEffect(() => { load(); }, [load, refreshTrigger]);

  const handleDelete = async (productId) => {
    if (!window.confirm('Delete this product and all its images?')) return;
    setDeleting(productId);
    try {
      const data = await sellerApi.deleteProduct(productId);
      if (data.success) {
        setProducts((ps) => ps.filter((p) => p.product_id !== productId));
        setTotal((t) => t - 1);
      } else {
        alert(data.error || 'Delete failed.');
      }
    } catch (err) {
      alert('Network error: ' + err.message);
    } finally {
      setDeleting(null);
    }
  };

  const handleStatusChange = async (productId, newStatus) => {
    try {
      const data = await sellerApi.updateProduct(productId, { availability_status: newStatus });
      if (data.success) {
        setProducts((ps) =>
          ps.map((p) => p.product_id === productId ? { ...p, availability_status: newStatus } : p)
        );
      } else {
        alert(data.error || 'Update failed.');
      }
    } catch (err) {
      alert('Network error: ' + err.message);
    } finally {
      setEditId(null);
    }
  };

  if (!sellerId) {
    return (
      <div className="bg-white rounded-2xl shadow-sm border border-purple-100 p-8 text-center text-gray-400">
        Register or log in as a seller to see your products.
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-purple-100 p-6">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-xl font-bold text-gray-800">My Products</h2>
        <span className="text-sm text-gray-400">{total} total</span>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">{error}</div>
      )}

      {loading ? (
        <div className="flex justify-center py-12">
          <div className="w-8 h-8 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin" />
        </div>
      ) : products.length === 0 ? (
        <div className="text-center py-12 text-gray-400 text-sm">
          No products yet. Upload your first dress above.
        </div>
      ) : (
        <div className="space-y-3">
          {products.map((prod) => (
            <div key={prod.product_id}
              className="flex items-center gap-4 p-3 border border-gray-100 rounded-xl hover:border-purple-200 transition-colors">

              {/* Primary image thumbnail */}
              <div className="flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden bg-gray-100">
                {prod.primary_image_url ? (
                  <img
                    src={sellerApi.resolveImageUrl(prod.primary_image_url)}
                    alt={prod.title}
                    className="w-full h-full object-cover"
                    onError={(e) => { e.target.style.display = 'none'; }}
                  />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-gray-300 text-2xl">?</div>
                )}
              </div>

              {/* Details */}
              <div className="flex-1 min-w-0">
                <p className="font-medium text-gray-800 text-sm truncate">{prod.title}</p>
                <p className="text-xs text-gray-400 mt-0.5">
                  {prod.category?.replace('_', ' ')} &bull; {prod.images?.length || 0} image(s)
                </p>
                <p className="text-xs text-purple-600 font-semibold mt-0.5">
                  PKR {prod.price?.toLocaleString()}
                  {prod.discount_price && (
                    <span className="ml-2 text-green-600">
                      Sale: PKR {prod.discount_price?.toLocaleString()}
                    </span>
                  )}
                </p>
              </div>

              {/* Status badge / editor */}
              <div className="flex-shrink-0">
                {editId === prod.product_id ? (
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value)}
                    onBlur={() => handleStatusChange(prod.product_id, editStatus)}
                    autoFocus
                    className="text-xs border border-purple-300 rounded px-2 py-1"
                  >
                    {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                ) : (
                  <button
                    onClick={() => { setEditId(prod.product_id); setEditStatus(prod.availability_status); }}
                    className={`text-xs px-2 py-1 rounded-full font-medium cursor-pointer ${STATUS_COLORS[prod.availability_status] || 'bg-gray-100 text-gray-600'}`}
                  >
                    {prod.availability_status}
                  </button>
                )}
              </div>

              {/* Delete */}
              <button
                onClick={() => handleDelete(prod.product_id)}
                disabled={deleting === prod.product_id}
                className="flex-shrink-0 text-xs text-red-400 hover:text-red-600 disabled:opacity-40 transition-colors px-2"
              >
                {deleting === prod.product_id ? '...' : 'Delete'}
              </button>
            </div>
          ))}
        </div>
      )}

      {/* Pagination */}
      {total > 10 && (
        <div className="flex justify-center gap-3 mt-5">
          <button onClick={() => setPage((p) => Math.max(1, p - 1))} disabled={page <= 1}
            className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-40 hover:border-purple-400">
            Prev
          </button>
          <span className="px-3 py-1 text-sm text-gray-500">
            Page {page} / {Math.ceil(total / 10)}
          </span>
          <button onClick={() => setPage((p) => p + 1)} disabled={page * 10 >= total}
            className="px-3 py-1 text-sm border border-gray-200 rounded-lg disabled:opacity-40 hover:border-purple-400">
            Next
          </button>
        </div>
      )}
    </div>
  );
}
