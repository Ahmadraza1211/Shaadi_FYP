import React, { useState, useRef } from 'react';
import sellerApi from '../../api/sellerApi';

const CATEGORIES = [
  { id: 'bridal_lehenga', label: 'Bridal Lehenga' },
  { id: 'bridal_sharara', label: 'Bridal Sharara' },
  { id: 'bridal_saree',   label: 'Bridal Saree'   },
];

const BRIDAL_TYPES   = ['formal', 'semi-formal', 'casual'];
const FABRICS        = ['silk', 'chiffon', 'organza', 'velvet', 'georgette', 'net', 'brocade', 'other'];
const EMBROIDERY_TYPES = ['zardozi', 'kaamdani', 'gota patti', 'mirror work', 'sequin', 'kundan', 'stonework', 'other'];

const EMPTY_FORM = {
  title: '', description: '', category: '', color: '',
  fabric: '', embroidery_type: '', bridal_type: 'formal',
  price: '', discount_price: '', stock_quantity: '1',
};

export default function ProductUpload({ sellerId, onUploaded }) {
  const [form, setForm]         = useState(EMPTY_FORM);
  const [images, setImages]     = useState([]);
  const [previews, setPreviews] = useState([]);
  const [loading, setLoading]   = useState(false);
  const [result, setResult]     = useState(null);
  const [error, setError]       = useState('');
  const fileRef                 = useRef(null);

  const set = (key) => (e) => setForm((f) => ({ ...f, [key]: e.target.value }));

  const handleFiles = (e) => {
    const files = Array.from(e.target.files).slice(0, 5);
    setImages(files);
    setPreviews(files.map((f) => URL.createObjectURL(f)));
  };

  const removeImage = (idx) => {
    setImages((imgs) => imgs.filter((_, i) => i !== idx));
    setPreviews((ps) => ps.filter((_, i) => i !== idx));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setResult(null);

    if (!sellerId) { setError('Please register or log in as a seller first.'); return; }
    if (!form.category) { setError('Category is required.'); return; }
    if (!form.title.trim()) { setError('Title is required.'); return; }
    if (!form.description.trim()) { setError('Description is required.'); return; }
    if (!form.price || isNaN(Number(form.price))) { setError('Valid price is required.'); return; }
    if (images.length === 0) { setError('Upload at least one image.'); return; }

    setLoading(true);
    try {
      const data = await sellerApi.uploadProduct(
        { ...form, seller_id: sellerId },
        images,
      );
      if (data.success) {
        setResult(data);
        setForm(EMPTY_FORM);
        setImages([]);
        setPreviews([]);
        if (fileRef.current) fileRef.current.value = '';
        if (onUploaded) onUploaded(data);
      } else {
        setError(data.error || 'Upload failed.');
      }
    } catch (err) {
      setError('Network error: ' + err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-purple-100 p-6">
      <h2 className="text-xl font-bold text-gray-800 mb-5">Upload New Product</h2>

      {result && (
        <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-xl text-sm text-green-700">
          Product uploaded! ID: <span className="font-mono font-semibold">{result.product_id}</span>
          {' '}— {result.images_saved} image(s) saved, {result.embeddings_extracted} embedding(s) extracted.
        </div>
      )}
      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-xl text-sm text-red-700">{error}</div>
      )}

      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Title + Category */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
            <input
              type="text" value={form.title} onChange={set('title')} required
              placeholder="e.g. Royal Red Bridal Lehenga"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category *</label>
            <select value={form.category} onChange={set('category')} required
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400">
              <option value="">— Select category —</option>
              {CATEGORIES.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </select>
          </div>
        </div>

        {/* Description */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
          <textarea
            value={form.description} onChange={set('description')} required rows={3}
            placeholder="e.g. deep red bridal lehenga with heavy gold zardozi embroidery and floral patterns"
            className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400"
          />
        </div>

        {/* Color + Fabric + Embroidery */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Color</label>
            <input type="text" value={form.color} onChange={set('color')} placeholder="e.g. deep red"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Fabric</label>
            <select value={form.fabric} onChange={set('fabric')}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400">
              <option value="">— Select fabric —</option>
              {FABRICS.map((f) => <option key={f} value={f}>{f}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Embroidery Type</label>
            <select value={form.embroidery_type} onChange={set('embroidery_type')}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400">
              <option value="">— Select embroidery —</option>
              {EMBROIDERY_TYPES.map((e) => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
        </div>

        {/* Bridal Type + Price + Discount + Stock */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Bridal Type</label>
            <select value={form.bridal_type} onChange={set('bridal_type')}
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400">
              {BRIDAL_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Price (PKR) *</label>
            <input type="number" value={form.price} onChange={set('price')} required min="0" placeholder="150000"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Discount Price</label>
            <input type="number" value={form.discount_price} onChange={set('discount_price')} min="0" placeholder="—"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Stock</label>
            <input type="number" value={form.stock_quantity} onChange={set('stock_quantity')} min="1" placeholder="1"
              className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-purple-400" />
          </div>
        </div>

        {/* Image upload */}
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Images * <span className="text-xs text-gray-400">(up to 5, JPG/PNG/WebP, max 5 MB each)</span>
          </label>
          <div
            className="border-2 border-dashed border-purple-200 rounded-xl p-4 text-center cursor-pointer hover:border-purple-400 transition-colors"
            onClick={() => fileRef.current?.click()}
          >
            <p className="text-sm text-gray-500">Click to select images or drag and drop</p>
            <input ref={fileRef} type="file" multiple accept="image/*" className="hidden" onChange={handleFiles} />
          </div>

          {previews.length > 0 && (
            <div className="mt-3 flex gap-3 flex-wrap">
              {previews.map((src, idx) => (
                <div key={idx} className="relative">
                  <img src={src} alt={`Preview ${idx + 1}`} className="w-20 h-20 object-cover rounded-lg border border-gray-200" />
                  {idx === 0 && (
                    <span className="absolute -top-1 -left-1 bg-purple-600 text-white text-xs px-1 rounded">Primary</span>
                  )}
                  <button type="button" onClick={() => removeImage(idx)}
                    className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white rounded-full text-xs flex items-center justify-center">
                    x
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        <button
          type="submit" disabled={loading}
          className="w-full py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white font-semibold rounded-xl
                     hover:from-purple-700 hover:to-pink-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Uploading & Extracting Embeddings...' : 'Upload Product'}
        </button>
      </form>
    </div>
  );
}
